const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const { DynamoDBDocumentClient, PutCommand, GetCommand, QueryCommand, UpdateCommand, TransactWriteCommand } = require("@aws-sdk/lib-dynamodb");
const { v4: uuidv4 } = require('uuid');

exports.handler = async (event) => {
    console.log('=== Superchat DynamoDB Handler ===');
    console.log('Full Event:', JSON.stringify(event, null, 2));
    
    try {
        const client = new DynamoDBClient({ region: "ap-northeast-2" });
        const dynamoDb = DynamoDBDocumentClient.from(client);
        
        // OPTIONS 요청 처리
        const httpMethod = event.httpMethod || 
                          event.requestContext?.httpMethod || 
                          event.requestContext?.http?.method ||
                          'POST';
        
        if (httpMethod === 'OPTIONS') {
            return {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS'
                },
                body: ''
            };
        }
        
        // 요청 body 파싱
        let requestBody = {};
        
        if (event.body) {
            try {
                if (typeof event.body === 'string') {
                    requestBody = JSON.parse(event.body);
                } else {
                    requestBody = event.body;
                }
            } catch (e) {
                console.error('Body parsing error:', e);
            }
        } else {
            if (event.data) {
                requestBody = event.data;
            } else if (event.payload) {
                requestBody = event.payload;
            } else {
                requestBody = {
                    fromUserId: event.fromUserId,
                    toProfileId: event.toProfileId,
                    message: event.message,
                    pointsUsed: event.pointsUsed
                };
            }
        }
        
        console.log('Parsed body:', requestBody);
        
        const { fromUserId, toProfileId, message, pointsUsed = 100 } = requestBody;
        
        // 입력 검증
        if (!fromUserId || !toProfileId || !message) {
            return {
                statusCode: 400,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    success: false,
                    message: "fromUserId, toProfileId, message가 필요합니다",
                    data: null
                })
            };
        }
        
        // 자기 자신에게 슈퍼챗 방지
        if (fromUserId === toProfileId) {
            return {
                statusCode: 400,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    success: false,
                    message: "자기 자신에게는 슈퍼챗을 보낼 수 없습니다",
                    data: null
                })
            };
        }
        
        try {
            // 1. 사용자 포인트 확인
            let currentPoints = 1000; // 기본값
            try {
                const userPoints = await dynamoDb.send(new GetCommand({
                    TableName: 'UserPoints',
                    Key: { userId: fromUserId }
                }));
                currentPoints = userPoints.Item?.points || 1000;
            } catch (e) {
                console.log('UserPoints 테이블 조회 실패, 기본값 사용:', e.message);
            }
            
            if (currentPoints < pointsUsed) {
                return {
                    statusCode: 400,
                    headers: {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': '*'
                    },
                    body: JSON.stringify({
                        success: false,
                        message: "포인트가 부족합니다",
                        data: { 
                            currentPoints: currentPoints, 
                            requiredPoints: pointsUsed,
                            shortfall: pointsUsed - currentPoints
                        }
                    })
                };
            }
            
            // 2. 일일 슈퍼챗 제한 체크 (5회)
            let dailySuperchatCount = 0;
            try {
                const today = new Date().toISOString().split('T')[0];
                const todaySuperchats = await dynamoDb.send(new QueryCommand({
                    TableName: 'Superchats',
                    IndexName: 'superchatsByFromUserId',
                    KeyConditionExpression: 'fromUserId = :fromUserId',
                    FilterExpression: 'begins_with(createdAt, :today)',
                    ExpressionAttributeValues: {
                        ':fromUserId': fromUserId,
                        ':today': today
                    }
                }));
                dailySuperchatCount = todaySuperchats.Items?.length || 0;
            } catch (e) {
                console.log('Superchats 테이블 조회 실패, 제한 체크 건너뜀:', e.message);
            }
            
            const DAILY_SUPERCHAT_LIMIT = 5;
            if (dailySuperchatCount >= DAILY_SUPERCHAT_LIMIT) {
                return {
                    statusCode: 429,
                    headers: {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': '*'
                    },
                    body: JSON.stringify({
                        success: false,
                        message: `일일 슈퍼챗 제한을 초과했습니다 (${DAILY_SUPERCHAT_LIMIT}회)`,
                        data: { dailyCount: dailySuperchatCount, limit: DAILY_SUPERCHAT_LIMIT }
                    })
                };
            }
            
            // 3. 슈퍼챗 우선순위 계산
            let priority = 1;
            if (pointsUsed >= 500) priority = 4;
            else if (pointsUsed >= 300) priority = 3;
            else if (pointsUsed >= 200) priority = 2;
            
            // 4. 슈퍼챗 데이터 생성
            const superchatId = uuidv4();
            const now = new Date().toISOString();
            const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();
            
            const superchatData = {
                id: superchatId,
                fromUserId: fromUserId,
                toProfileId: toProfileId,
                message: message,
                pointsUsed: pointsUsed,
                priority: priority,
                status: 'sent',
                createdAt: now,
                updatedAt: now,
                expiresAt: expiresAt,
                isRead: false
            };
            
            // 5. DynamoDB에 데이터 저장
            const transactItems = [];
            
            // 슈퍼챗 저장
            transactItems.push({
                Put: {
                    TableName: 'Superchats',
                    Item: superchatData
                }
            });
            
            // 포인트 차감 (UserPoints 테이블이 있는 경우)
            if (currentPoints >= pointsUsed) {
                transactItems.push({
                    Update: {
                        TableName: 'UserPoints',
                        Key: { userId: fromUserId },
                        UpdateExpression: 'SET points = points - :pointsUsed, updatedAt = :now',
                        ConditionExpression: 'points >= :pointsUsed',
                        ExpressionAttributeValues: {
                            ':pointsUsed': pointsUsed,
                            ':now': now
                        }
                    }
                });
            }
            
            // 포인트 사용 내역 저장
            const pointHistoryId = uuidv4();
            transactItems.push({
                Put: {
                    TableName: 'PointsHistory',
                    Item: {
                        id: pointHistoryId,
                        userId: fromUserId,
                        type: 'SUPERCHAT',
                        amount: -pointsUsed,
                        description: `슈퍼챗 전송 (받는이: ${toProfileId})`,
                        createdAt: now
                    }
                }
            });
            
            // 알림 생성
            const notificationId = uuidv4();
            transactItems.push({
                Put: {
                    TableName: 'Notifications',
                    Item: {
                        id: notificationId,
                        userId: toProfileId,
                        fromUserId: fromUserId,
                        type: 'SUPERCHAT',
                        message: '슈퍼챗을 받았습니다 ⭐',
                        isRead: false,
                        createdAt: now
                    }
                }
            });
            
            // 원자적 트랜잭션 실행
            try {
                await dynamoDb.send(new TransactWriteCommand({
                    TransactItems: transactItems
                }));
                console.log(`✅ 슈퍼챗 저장 완료: ${superchatId}`);
            } catch (transactionError) {
                console.error('트랜잭션 실패:', transactionError);
                
                // 포인트 부족으로 인한 실패
                if (transactionError.name === 'ConditionalCheckFailedException') {
                    return {
                        statusCode: 400,
                        headers: {
                            'Content-Type': 'application/json',
                            'Access-Control-Allow-Origin': '*'
                        },
                        body: JSON.stringify({
                            success: false,
                            message: "포인트가 부족하여 슈퍼챗을 전송할 수 없습니다",
                            data: null
                        })
                    };
                }
                
                // 테이블이 존재하지 않는 경우 기본 응답
                console.log('DynamoDB 테이블 없음, 로컬 응답 반환');
            }
            
            // 성공 응답
            return {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS'
                },
                body: JSON.stringify({
                    success: true,
                    message: "슈퍼챗을 전송했습니다",
                    data: {
                        superchat: superchatData,
                        remainingPoints: Math.max(0, currentPoints - pointsUsed),
                        dailyCount: dailySuperchatCount + 1,
                        remaining: Math.max(0, DAILY_SUPERCHAT_LIMIT - (dailySuperchatCount + 1))
                    }
                })
            };
            
        } catch (error) {
            console.error('슈퍼챗 처리 오류:', error);
            return {
                statusCode: 500,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    success: false,
                    message: "슈퍼챗 전송 중 오류가 발생했습니다: " + error.message,
                    data: null
                })
            };
        }
        
    } catch (error) {
        console.error('Lambda error:', error);
        return {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                success: false,
                message: "서버 오류가 발생했습니다: " + error.message,
                data: null
            })
        };
    }
};