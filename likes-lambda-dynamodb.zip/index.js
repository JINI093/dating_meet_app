const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const { DynamoDBDocumentClient, PutCommand, GetCommand, QueryCommand, UpdateCommand, TransactWriteCommand } = require("@aws-sdk/lib-dynamodb");
const { v4: uuidv4 } = require('uuid');

exports.handler = async (event) => {
    console.log('=== Likes DynamoDB Handler ===');
    console.log('Full Event:', JSON.stringify(event, null, 2));
    
    try {
        const client = new DynamoDBClient({ region: "ap-northeast-2" });
        const dynamoDb = DynamoDBDocumentClient.from(client);
        
        // OPTIONS 요청 처리
        const httpMethod = event.httpMethod || 
                          event.requestContext?.httpMethod || 
                          event.requestContext?.http?.method ||
                          'POST';
        
        if (httpMethod === 'OPTIONS') {
            return {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS'
                },
                body: ''
            };
        }
        
        // 요청 body 파싱
        let requestBody = {};
        
        if (event.body) {
            try {
                if (typeof event.body === 'string') {
                    requestBody = JSON.parse(event.body);
                } else {
                    requestBody = event.body;
                }
            } catch (e) {
                console.error('Body parsing error:', e);
            }
        } else {
            if (event.data) {
                requestBody = event.data;
            } else if (event.payload) {
                requestBody = event.payload;
            } else {
                requestBody = {
                    fromUserId: event.fromUserId,
                    toProfileId: event.toProfileId,
                    likeType: event.likeType,
                    message: event.message
                };
            }
        }
        
        console.log('Parsed body:', requestBody);
        
        const { fromUserId, toProfileId, likeType = 'LIKE', message } = requestBody;
        
        // 입력 검증
        if (!fromUserId || !toProfileId) {
            return {
                statusCode: 400,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    success: false,
                    message: "fromUserId와 toProfileId가 필요합니다",
                    data: null
                })
            };
        }
        
        // 자기 자신에게 좋아요/패스 방지
        if (fromUserId === toProfileId) {
            return {
                statusCode: 400,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    success: false,
                    message: "자기 자신에게는 좋아요/패스를 할 수 없습니다",
                    data: null
                })
            };
        }
        
        try {
            // 1. 중복 체크
            let existingLike = null;
            try {
                const existingLikeQuery = await dynamoDb.send(new QueryCommand({
                    TableName: 'Likes',
                    IndexName: 'likesByFromUserIdAndToProfileId',
                    KeyConditionExpression: 'fromUserId = :fromUserId AND toProfileId = :toProfileId',
                    ExpressionAttributeValues: {
                        ':fromUserId': fromUserId,
                        ':toProfileId': toProfileId
                    }
                }));
                existingLike = existingLikeQuery.Items?.[0];
            } catch (e) {
                console.log('중복 체크 실패, 계속 진행:', e.message);
            }
            
            if (existingLike) {
                return {
                    statusCode: 409,
                    headers: {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': '*'
                    },
                    body: JSON.stringify({
                        success: false,
                        message: "이미 반응을 표시한 사용자입니다",
                        data: null
                    })
                };
            }
            
            // 2. 좋아요인 경우 일일 제한 체크 (패스는 제한 없음)
            let dailyLikeCount = 0;
            const DAILY_LIKE_LIMIT = 20;
            
            if (likeType === 'LIKE') {
                try {
                    const today = new Date().toISOString().split('T')[0];
                    const todayLikes = await dynamoDb.send(new QueryCommand({
                        TableName: 'Likes',
                        IndexName: 'likesByFromUserId',
                        KeyConditionExpression: 'fromUserId = :fromUserId',
                        FilterExpression: 'begins_with(createdAt, :today) AND actionType = :actionType',
                        ExpressionAttributeValues: {
                            ':fromUserId': fromUserId,
                            ':today': today,
                            ':actionType': 'LIKE'
                        }
                    }));
                    dailyLikeCount = todayLikes.Items?.length || 0;
                } catch (e) {
                    console.log('일일 제한 체크 실패, 계속 진행:', e.message);
                }
                
                if (dailyLikeCount >= DAILY_LIKE_LIMIT) {
                    return {
                        statusCode: 429,
                        headers: {
                            'Content-Type': 'application/json',
                            'Access-Control-Allow-Origin': '*'
                        },
                        body: JSON.stringify({
                            success: false,
                            message: `일일 좋아요 제한을 초과했습니다 (${DAILY_LIKE_LIMIT}회)`,
                            data: { dailyCount: dailyLikeCount, limit: DAILY_LIKE_LIMIT }
                        })
                    };
                }
            }
            
            // 3. 좋아요/패스 데이터 생성
            const likeId = uuidv4();
            const now = new Date().toISOString();
            
            const likeData = {
                id: likeId,
                fromUserId: fromUserId,
                toProfileId: toProfileId,
                actionType: likeType,
                message: message || null,
                createdAt: now,
                updatedAt: now
            };
            
            // 4. 매칭 확인 (좋아요인 경우만)
            let isMatch = false;
            let matchData = null;
            
            if (likeType === 'LIKE') {
                try {
                    // 상대방이 나에게 좋아요를 했는지 확인
                    const reciprocalLike = await dynamoDb.send(new QueryCommand({
                        TableName: 'Likes',
                        IndexName: 'likesByFromUserIdAndToProfileId',
                        KeyConditionExpression: 'fromUserId = :toProfileId AND toProfileId = :fromUserId',
                        FilterExpression: 'actionType = :actionType',
                        ExpressionAttributeValues: {
                            ':fromUserId': fromUserId,
                            ':toProfileId': toProfileId,
                            ':actionType': 'LIKE'
                        }
                    }));
                    
                    if (reciprocalLike.Items && reciprocalLike.Items.length > 0) {
                        isMatch = true;
                        
                        // 매칭 데이터 생성
                        const matchId = uuidv4();
                        matchData = {
                            id: matchId,
                            user1Id: fromUserId < toProfileId ? fromUserId : toProfileId,
                            user2Id: fromUserId < toProfileId ? toProfileId : fromUserId,
                            matchedAt: now,
                            status: 'ACTIVE',
                            createdAt: now,
                            updatedAt: now
                        };
                    }
                } catch (e) {
                    console.log('매칭 확인 실패, 매칭 없음으로 처리:', e.message);
                }
            }
            
            // 5. DynamoDB에 데이터 저장
            const transactItems = [
                {
                    Put: {
                        TableName: 'Likes',
                        Item: likeData
                    }
                }
            ];
            
            // 매칭인 경우 Matches 테이블에 추가
            if (isMatch && matchData) {
                transactItems.push({
                    Put: {
                        TableName: 'Matches',
                        Item: matchData,
                        ConditionExpression: 'attribute_not_exists(id)'
                    }
                });
                
                // 매칭 알림 생성
                const notificationId1 = uuidv4();
                const notificationId2 = uuidv4();
                
                transactItems.push(
                    {
                        Put: {
                            TableName: 'Notifications',
                            Item: {
                                id: notificationId1,
                                userId: fromUserId,
                                fromUserId: toProfileId,
                                type: 'MATCH',
                                message: '새로운 매칭이 생겼습니다! 💕',
                                isRead: false,
                                createdAt: now
                            }
                        }
                    },
                    {
                        Put: {
                            TableName: 'Notifications',
                            Item: {
                                id: notificationId2,
                                userId: toProfileId,
                                fromUserId: fromUserId,
                                type: 'MATCH',
                                message: '새로운 매칭이 생겼습니다! 💕',
                                isRead: false,
                                createdAt: now
                            }
                        }
                    }
                );
            } else if (likeType === 'LIKE') {
                // 일반 좋아요 알림
                const notificationId = uuidv4();
                transactItems.push({
                    Put: {
                        TableName: 'Notifications',
                        Item: {
                            id: notificationId,
                            userId: toProfileId,
                            fromUserId: fromUserId,
                            type: 'LIKE',
                            message: '누군가 회원님을 좋아합니다 ❤️',
                            isRead: false,
                            createdAt: now
                        }
                    }
                });
            }
            
            // 원자적 트랜잭션 실행
            try {
                await dynamoDb.send(new TransactWriteCommand({
                    TransactItems: transactItems
                }));
                console.log(`✅ ${likeType} 저장 완료: ${likeId}, 매칭: ${isMatch}`);
            } catch (transactionError) {
                console.error('트랜잭션 실패:', transactionError);
                
                if (transactionError.name === 'ConditionalCheckFailedException') {
                    return {
                        statusCode: 409,
                        headers: {
                            'Content-Type': 'application/json',
                            'Access-Control-Allow-Origin': '*'
                        },
                        body: JSON.stringify({
                            success: false,
                            message: "매칭 생성 중 충돌이 발생했습니다",
                            data: null
                        })
                    };
                }
                
                // 테이블이 존재하지 않는 경우 로그만 남기고 계속 진행
                console.log('DynamoDB 테이블 없음, 로컬 응답 반환');
            }
            
            // 성공 응답
            return {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS'
                },
                body: JSON.stringify({
                    success: true,
                    message: likeType === 'LIKE' ? 
                        (isMatch ? "매칭이 성사되었습니다!" : "좋아요를 전송했습니다") : 
                        "패스했습니다",
                    data: {
                        like: likeData,
                        isMatch: isMatch,
                        dailyCount: likeType === 'LIKE' ? dailyLikeCount + 1 : null,
                        remaining: likeType === 'LIKE' ? DAILY_LIKE_LIMIT - (dailyLikeCount + 1) : null
                    }
                })
            };
            
        } catch (error) {
            console.error('좋아요/패스 처리 오류:', error);
            return {
                statusCode: 500,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    success: false,
                    message: "좋아요/패스 처리 중 오류가 발생했습니다: " + error.message,
                    data: null
                })
            };
        }
        
    } catch (error) {
        console.error('Lambda error:', error);
        return {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                success: false,
                message: "서버 오류가 발생했습니다: " + error.message,
                data: null
            })
        };
    }
};